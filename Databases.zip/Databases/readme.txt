~Guide as we know it to Database Files~


20130408_mylyntasks.xml:
- feature requests using Bugzilla as an issue tracker
- 425 feature requests
- 10 'Duplicate'

	According to us:
	- 425 feature requests 	:)
	- 17 'Duplicate' 	:(

20130514_argouml.xml:
- feature requests using Bugzilla as an issue tracker
- 1273 feature requests
- 101 'Duplicate'

	According to us:
	- 1273 feature requests :)
	- 132 'Duplicate' 	:(

20130514_netbeans.xml:
- feature requests using Bugzilla as an issue tracker
- 4200 feature requests
- 342 'Duplicate'
	
	According to us: 
	- 4451 feature requests :(
	- 566 'Duplicate' 	:(

ArgoUML_cossim_LO_SP_DW_SM_SC_AC:
- Note: Only 2 columns, all of the cosine similaritys are set to 0

Mylyn_cossim_LO_SP_DW_SM_SC_AC:
- Note: Only 2 columns, all of the cosine similaritys are set to 0

MylynTaskStopwords:
- the 66 Stop Words manually added

Netbeans_duplicatesLSA_LO_SP_DW_SM_SC_AC:
- feature_id; dup_id; rank; sim

Netbeans_Top50_LSAk1700_LO_SP_DW_SM_SC_AC:


Netbeans_Top50_TFIDF_LO_SP_DW_SM_SC_AC:

