//@author: Rrezarta Krasniqi

public class Config
{
    private String dirPath;

    public String getDirPath()
    {
            return this.dirPath;
    }

    public void setDirPath(String dirPath)
    {
            this.dirPath = dirPath;
    }
}